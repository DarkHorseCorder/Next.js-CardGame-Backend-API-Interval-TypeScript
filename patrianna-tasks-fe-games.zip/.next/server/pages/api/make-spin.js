"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/make-spin";
exports.ids = ["pages/api/make-spin"];
exports.modules = {

/***/ "(api)/./src/pages/api/make-spin.ts":
/*!************************************!*\
  !*** ./src/pages/api/make-spin.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\n// Next.js API route support: https://nextjs.org/docs/api-routes/introduction\n// POST /api/make-spin\n// Required fields in body: { guess: 'red' | 'black' }\nasync function handler(req, res) {\n    const { guess  } = JSON.parse(req.body);\n    if (!guess || guess !== \"red\" && guess !== \"black\") {\n        return res.status(400).json({\n            error: 'Invalid guess. Provide either \"red\" or \"black\".' + req.body\n        });\n    }\n    try {\n        const deck = await fetch(\"https://deckofcardsapi.com/api/deck/new/draw/?count=1\");\n        if (!deck.ok) {\n            throw new Error(deck.statusText);\n        }\n        const deckJson = await deck.json();\n        const card = deckJson.cards[0];\n        const { value , suit  } = card;\n        const isCorrect = guess === \"red\" && suit === \"HEARTS\" || guess === \"black\" && suit === \"SPADES\";\n        const color = suit === \"HEARTS\" || suit === \"DIAMONDS\" ? \"RED\" : \"BLACK\";\n        return res.status(200).json({\n            guess,\n            isCorrect,\n            card: {\n                value,\n                suit,\n                color\n            }\n        });\n    } catch (error) {\n        console.error(\"Error fetching deck :: \", error);\n        res.status(500).json({\n            error: \"Error fetching deck. Check /api/make-spin\"\n        });\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9zcmMvcGFnZXMvYXBpL21ha2Utc3Bpbi50cy5qcyIsIm1hcHBpbmdzIjoiOzs7O0FBQUEsNkVBQTZFO0FBVTdFLHNCQUFzQjtBQUN0QixzREFBc0Q7QUFFdkMsZUFBZUEsUUFDNUJDLEdBQW1CLEVBQ25CQyxHQUFtQyxFQUNuQztJQUNBLE1BQU0sRUFBRUMsTUFBSyxFQUFFLEdBQUdDLEtBQUtDLEtBQUssQ0FBQ0osSUFBSUssSUFBSTtJQUNyQyxJQUFJLENBQUNILFNBQVVBLFVBQVUsU0FBU0EsVUFBVSxTQUFVO1FBQ3BELE9BQU9ELElBQ0pLLE1BQU0sQ0FBQyxLQUNQQyxJQUFJLENBQUM7WUFBRUMsT0FBTyxvREFBb0RSLElBQUlLLElBQUk7UUFBQztJQUNoRixDQUFDO0lBRUQsSUFBSTtRQUNGLE1BQU1JLE9BQU8sTUFBTUMsTUFDakI7UUFFRixJQUFJLENBQUNELEtBQUtFLEVBQUUsRUFBRTtZQUNaLE1BQU0sSUFBSUMsTUFBTUgsS0FBS0ksVUFBVSxFQUFDO1FBQ2xDLENBQUM7UUFDRCxNQUFNQyxXQUFXLE1BQU1MLEtBQUtGLElBQUk7UUFDaEMsTUFBTVEsT0FBT0QsU0FBU0UsS0FBSyxDQUFDLEVBQUU7UUFFOUIsTUFBTSxFQUFFQyxNQUFLLEVBQUVDLEtBQUksRUFBRSxHQUFHSDtRQUN4QixNQUFNSSxZQUFZLFVBQVcsU0FBU0QsU0FBUyxZQUFjaEIsVUFBVSxXQUFXZ0IsU0FBUztRQUMzRixNQUFNRSxRQUFRRixTQUFTLFlBQVlBLFNBQVMsYUFBYSxRQUFRLE9BQU87UUFJeEUsT0FBT2pCLElBQUlLLE1BQU0sQ0FBQyxLQUFLQyxJQUFJLENBQUM7WUFBRUw7WUFBT2lCO1lBQVdKLE1BQU07Z0JBQUVFO2dCQUFPQztnQkFBTUU7WUFBTTtRQUFFO0lBQy9FLEVBQUUsT0FBT1osT0FBTztRQUNkYSxRQUFRYixLQUFLLENBQUMsMkJBQTJCQTtRQUN6Q1AsSUFBSUssTUFBTSxDQUFDLEtBQUtDLElBQUksQ0FBQztZQUFFQyxPQUFPO1FBQTRDO0lBQzVFO0FBQ0YsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2ZlLWdhbWVzLXRhc2svLi9zcmMvcGFnZXMvYXBpL21ha2Utc3Bpbi50cz9lMjMwIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIE5leHQuanMgQVBJIHJvdXRlIHN1cHBvcnQ6IGh0dHBzOi8vbmV4dGpzLm9yZy9kb2NzL2FwaS1yb3V0ZXMvaW50cm9kdWN0aW9uXHJcbmltcG9ydCB0eXBlIHsgTmV4dEFwaVJlcXVlc3QsIE5leHRBcGlSZXNwb25zZSB9IGZyb20gJ25leHQnXHJcblxyXG50eXBlIERhdGEgPSB7XHJcbiAgZ3Vlc3M6ICdyZWQnIHwgJ2JsYWNrJ1xyXG4gIGlzQ29ycmVjdDogYm9vbGVhblxyXG4gIGNhcmQ6IHsgdmFsdWU6IHN0cmluZzsgc3VpdDogc3RyaW5nLCBjb2xvcjogJ1JFRCcgfCAnQkxBQ0snIH1cclxuICBlcnJvcj86IHN0cmluZ1xyXG59XHJcblxyXG4vLyBQT1NUIC9hcGkvbWFrZS1zcGluXHJcbi8vIFJlcXVpcmVkIGZpZWxkcyBpbiBib2R5OiB7IGd1ZXNzOiAncmVkJyB8ICdibGFjaycgfVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24gaGFuZGxlcihcclxuICByZXE6IE5leHRBcGlSZXF1ZXN0LFxyXG4gIHJlczogTmV4dEFwaVJlc3BvbnNlPFBhcnRpYWw8RGF0YT4+XHJcbikge1xyXG4gIGNvbnN0IHsgZ3Vlc3MgfSA9IEpTT04ucGFyc2UocmVxLmJvZHkpXHJcbiAgaWYgKCFndWVzcyB8fCAoZ3Vlc3MgIT09ICdyZWQnICYmIGd1ZXNzICE9PSAnYmxhY2snKSkge1xyXG4gICAgcmV0dXJuIHJlc1xyXG4gICAgICAuc3RhdHVzKDQwMClcclxuICAgICAgLmpzb24oeyBlcnJvcjogJ0ludmFsaWQgZ3Vlc3MuIFByb3ZpZGUgZWl0aGVyIFwicmVkXCIgb3IgXCJibGFja1wiLicgKyByZXEuYm9keSB9KVxyXG4gIH1cclxuXHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGRlY2sgPSBhd2FpdCBmZXRjaChcclxuICAgICAgJ2h0dHBzOi8vZGVja29mY2FyZHNhcGkuY29tL2FwaS9kZWNrL25ldy9kcmF3Lz9jb3VudD0xJ1xyXG4gICAgKVxyXG4gICAgaWYgKCFkZWNrLm9rKSB7XHJcbiAgICAgIHRocm93IG5ldyBFcnJvcihkZWNrLnN0YXR1c1RleHQpXHJcbiAgICB9XHJcbiAgICBjb25zdCBkZWNrSnNvbiA9IGF3YWl0IGRlY2suanNvbigpXHJcbiAgICBjb25zdCBjYXJkID0gZGVja0pzb24uY2FyZHNbMF1cclxuXHJcbiAgICBjb25zdCB7IHZhbHVlLCBzdWl0IH0gPSBjYXJkXHJcbiAgICBjb25zdCBpc0NvcnJlY3QgPSAoZ3Vlc3MgPT09ICdyZWQnICYmIHN1aXQgPT09ICdIRUFSVFMnKSB8fCAoZ3Vlc3MgPT09ICdibGFjaycgJiYgc3VpdCA9PT0gJ1NQQURFUycpXHJcbiAgICBjb25zdCBjb2xvciA9IHN1aXQgPT09ICdIRUFSVFMnIHx8IHN1aXQgPT09ICdESUFNT05EUycgPyAnUkVEJyA6ICdCTEFDSydcclxuXHJcblxyXG5cclxuICAgIHJldHVybiByZXMuc3RhdHVzKDIwMCkuanNvbih7IGd1ZXNzLCBpc0NvcnJlY3QsIGNhcmQ6IHsgdmFsdWUsIHN1aXQsIGNvbG9yIH0gfSlcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcignRXJyb3IgZmV0Y2hpbmcgZGVjayA6OiAnLCBlcnJvcilcclxuICAgIHJlcy5zdGF0dXMoNTAwKS5qc29uKHsgZXJyb3I6ICdFcnJvciBmZXRjaGluZyBkZWNrLiBDaGVjayAvYXBpL21ha2Utc3BpbicgfSlcclxuICB9XHJcbn1cclxuIl0sIm5hbWVzIjpbImhhbmRsZXIiLCJyZXEiLCJyZXMiLCJndWVzcyIsIkpTT04iLCJwYXJzZSIsImJvZHkiLCJzdGF0dXMiLCJqc29uIiwiZXJyb3IiLCJkZWNrIiwiZmV0Y2giLCJvayIsIkVycm9yIiwic3RhdHVzVGV4dCIsImRlY2tKc29uIiwiY2FyZCIsImNhcmRzIiwidmFsdWUiLCJzdWl0IiwiaXNDb3JyZWN0IiwiY29sb3IiLCJjb25zb2xlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./src/pages/api/make-spin.ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./src/pages/api/make-spin.ts"));
module.exports = __webpack_exports__;

})();